﻿using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Linq;
using System.Xml;
using System.Collections;

namespace @antiVirus
{
    class Program
    {
        const string malwarePath = @"..\..\..\..\Train\Malware Sample";
        const string nonMalwarePath = @"..\..\..\..\Train\Benign";
        const string patternFolder = @"..\..\..\patterns";
        const int minRangeLen = 96;
        const int minPatternLen = 32;
            
        static void Main()
        {
            Malware.writeMalwarePatterns();
            Malware.readMalwarePatterns();

            for (int malwareCategory = 1; malwareCategory <= 20; ++malwareCategory)
            {
                Console.WriteLine(malwareCategory + ":");
                Malware.showMismatches(malwareCategory);
                Malware.showMatches(nonMalwarePath, malwareCategory);
                Console.WriteLine();
            }

            Console.Write("Folder Path: ");
            string folderPath = Console.ReadLine();

            string malwareFolder = folderPath + "\\" + "Malwares";
            if (!Directory.Exists(malwareFolder))
                Directory.CreateDirectory(malwareFolder);

            var files = Directory.GetFiles(folderPath);
            for (int i = 0; i < files.Count(); ++i)
                if (Malware.isMalware(files[i]))
                    File.Move(files[i], malwareFolder + "\\" + files[i].Substring(files[i].LastIndexOf('\\') + 1));
        }

        class Malware
        {
            private Malware(List<byte[]> patterns)
            {
                this.patterns = patterns;
            }

            static Malware()
            {
                malwares = new List<Malware>();
            }

            private List<byte[]> patterns;

            private static List<Malware> malwares;

            public static void writeMalwarePatterns()
            {
                if (!Directory.Exists(patternFolder))
                {
                    Directory.CreateDirectory(patternFolder);
                    for (int category = 1; category <= Directory.EnumerateDirectories(malwarePath).Count(); ++category)
                    {
                        Directory.CreateDirectory(patternFolder + "\\" + category.ToString());
                    }
                }

                foreach (var folder in Directory.EnumerateDirectories(malwarePath))
                {
                    int backslashIndex = folder.LastIndexOf('\\');
                    string malwareCategory = folder.Substring(backslashIndex + 1);

                    if (malwareCategory != "5")
                        continue;

                    var _files = Directory.GetFiles(malwarePath + "\\" + malwareCategory).ToList();
                    var files = (from f in _files orderby new FileInfo(f).Length ascending select f).ToList();
                    List<byte[]> fileBytes = new List<byte[]>(files.Count);
                    List<Range>[] ranges = new List<Range>[files.Count];
                    List<byte[]> patterns = new List<byte[]>();
                    bool[] isCleared = new bool[files.Count];
                    int clearedCount = 0;
                    int patternNum = 1;

                    for (int i = 0; i < files.Count; ++i)
                    {
                        using (FileStream file = new FileStream(files[i], FileMode.Open))
                        {
                            fileBytes.Add(new byte[(int)file.Length]);
                            file.Read(fileBytes[i]);
                        }
                    }

                    foreach (var pattern in Directory.EnumerateFiles(patternFolder + "\\" + malwareCategory))
                    {
                        FileStream fs = new FileStream(pattern, FileMode.Open);
                        int len = (int)fs.Length;
                        byte[] readPattern = new byte[len];
                        fs.Read(readPattern, 0, len);
                        fs.Close();

                        for (int i = 0; i < files.Count; ++i)
                        {
                            if (!isCleared[i])
                            {
                                if (BoyerMoore.IndexOf(fileBytes[i], readPattern) != -1)
                                {
                                    isCleared[i] = true;
                                    ++clearedCount;
                                }
                            }
                        }
                        ++patternNum;
                    }

                    for (int i = 0; i < files.Count; ++i)
                    {
                        int start = 0;
                        for (start = 0; start < fileBytes[i].Length && fileBytes[i][start] == 0; ++start) ;
                        ranges[i] = new List<Range>();
                        int counter = 0;

                        for (int end = start; end < fileBytes[i].Length; ++end)
                        {
                            if (fileBytes[i][end] == 0)
                            {
                                ++counter;
                                if (counter == 16)
                                {
                                    if (end - 16 - start + 1 >= minRangeLen)
                                        ranges[i].Add(new Range(start, end - 1));

                                    while (end < fileBytes[i].Length && fileBytes[i][end] == 0)
                                        ++end;

                                    start = end;
                                    --end;
                                    counter = 0;
                                }
                            }
                        }
                    }

                    Console.WriteLine("processing malware " + malwareCategory + ":");
                    Console.WriteLine(clearedCount + "/" + files.Count);

                    for (int i = 0; clearedCount != files.Count; ++i)
                    {
                        while (i != files.Count && isCleared[i])
                            ++i;

                        if (i == files.Count)
                            break;

                        bool reachedEnd = false;
                        double percent = 0.04;
                        int j = i + 1;
                        while (j < files.Count && isCleared[j])
                            ++j;
                        if (j == files.Count)
                        {
                            reachedEnd = true;
                            j = 0;
                        }

                        while (Math.Abs(percent - 0) >= 0.009)
                        {
                            if (!isCleared[j] || reachedEnd)
                            {
                                Range range;
                                try
                                {
                                    range = LongestCommonSubarray(fileBytes[i], ranges[i], fileBytes[j], ranges[j]);
                                }
                                catch (Exception)
                                {
                                    break;
                                }

                                byte[] pattern = new byte[range.end - range.start + 1];

                                Array.Copy(fileBytes[i], range.start, pattern, 0, pattern.Length);
                                List<int> matchingFiles = new List<int>();
                                int checkCounter = 2;

                                for (int check = 0; check < files.Count; ++check)
                                {
                                    if ((checkCounter <= files.Count * percent  || !isCleared[check]) && check != j && check != i)
                                    {
                                        if (BoyerMoore.IndexOf(fileBytes[check], pattern) != -1)
                                        {
                                            ++checkCounter;
                                            if (!isCleared[check])
                                            {
                                                matchingFiles.Add(check);
                                            }
                                        }
                                    }
                                }

                                if (checkCounter > files.Count * percent)
                                {
                                    foreach (int check in matchingFiles)
                                        isCleared[check] = true;
                                    isCleared[i] = true;
                                    clearedCount += matchingFiles.Count + 1;

                                    if (!isCleared[j])
                                    {
                                        isCleared[j] = true;
                                        ++clearedCount;
                                    }

                                    using (FileStream fs = new FileStream(patternFolder + "\\" + malwareCategory + "\\" + (patternNum++), FileMode.Create))
                                    {
                                        fs.Write(pattern);
                                    }

                                    Console.WriteLine(clearedCount + "/" + files.Count);
                                    break;
                                }
                            }
                            ++j;
                            if (j == files.Count)
                            {
                                j = 0;
                                reachedEnd = true;
                                percent -= 0.01;
                            }
                        }
                    }

                    Console.WriteLine();
                }
            }

            public static void readMalwarePatterns()
            {
                for (int malwareCategory = 1; malwareCategory <= (Directory.EnumerateDirectories(malwarePath)).Count(); ++malwareCategory)
                {
                    List<byte[]> patterns = new List<byte[]>();
                    byte[] readPattern;
                    int len;

                    foreach (var pattern in Directory.EnumerateFiles(patternFolder + "\\" + malwareCategory))
                    {
                        FileStream fs = new FileStream(pattern, FileMode.Open);
                        len = (int)fs.Length;
                        readPattern = new byte[len];
                        fs.Read(readPattern, 0, len);
                        fs.Close();
                        patterns.Add(readPattern);
                    }

                    malwares.Add(new Malware(patterns));
                }
            }

            public static bool isMalware(string filePath)
            {
                foreach (var m in malwares)
                    if (m.matches(filePath))
                        return true;
                return false;
            }

            public static void showMatches(string folderPath, int malwareCategory)
            {
                Malware malware = malwares[malwareCategory - 1];
                if (malware.patterns.Count == 0) return;
                int count = 0;
                foreach (var file in Directory.EnumerateFiles(folderPath))
                {
                    if (malware.matches(file))
                    {
                        ++count;
                        //Console.WriteLine(file);
                    }
                }
                Console.WriteLine(count);
            }

            public static void showMismatches(int malwareCategory)
            {
                Malware malware = malwares[malwareCategory - 1];
                if (malware.patterns.Count == 0) return;
                int count = 0;
                foreach (var file in Directory.EnumerateFiles(malwarePath + "\\" + malwareCategory))
                {
                    if (!malware.matches(file))
                    {
                        ++count;
                        //Console.WriteLine(file);
                    }
                }
                Console.WriteLine(count);
            }

            private bool matches(string filePath)
            {
                FileStream fs = new FileStream(filePath, FileMode.Open);
                int len = (int)fs.Length;
                byte[] bits = new byte[len];
                fs.Read(bits, 0, len);
                fs.Close();
                foreach (var pattern in patterns)
                    if (BoyerMoore.IndexOf(bits, pattern) != -1)
                        return true;
                return false;
            }

            private static Range LongestCommonSubarray(byte[] A, List<Range> a_ranges, byte[] B, List<Range> b_ranges)
            {
                // end - start = length - 1

                int maxLen = 0, s = 0;

                List<byte[]> nonMalwares = new List<byte[]>();
                var files = Directory.EnumerateFiles(nonMalwarePath).ToList();
                for (int i = 0; i < files.Count; ++i)
                {
                    using (FileStream fs = new FileStream(files[i], FileMode.Open))
                    {
                        nonMalwares.Add(new byte[(int)fs.Length]);
                        fs.Read(nonMalwares[i]);
                    }
                }
                bool flag = true;
                foreach (var a_range in a_ranges)
                {
                    foreach (var b_range in b_ranges)
                    {
                        int a_len = a_range.end - a_range.start + 1;
                        int b_len = b_range.end - b_range.start + 1;
                        byte[,] dp = new byte[a_len + 1, b_len + 1];

                        for (int i = a_len - 1; i >= 0; --i)
                        {
                            for (int j = b_len - 1; j >= 0; --j)
                            {
                                if (A[i] == B[j])
                                    dp[i, j] = (byte)(dp[i + 1, j + 1] + 1);
                            }
                        }

                        for (int i = 0; i < a_len; ++i)
                        {
                            for (int j = 0; j < b_len; ++j)
                            {
                                if (dp[i, j] > maxLen)
                                {
                                    s = a_range.start + i;
                                    maxLen = dp[i, j];
                                }
                            }
                        }

                        if (maxLen >= minPatternLen)
                        {
                            byte[] pattern = new byte[maxLen + 1];
                            Array.Copy(A, s, pattern, 0, maxLen + 1);
                            
                            for (int i = 0; i < nonMalwares.Count; ++i)
                                if (BoyerMoore.IndexOf(nonMalwares[i], pattern) != -1)
                                {
                                    flag = false;
                                }

                            if (flag)
                                return new Range(s, s + maxLen);
                        }
                    }
                }

                if (flag)
                    return new Range(s, s + maxLen);
                else
                    throw new Exception();
            }

            private static class BoyerMoore
            {
                public static int IndexOf(byte[] haystack, byte[] needle)
                {
                    if (needle.Length == 0)
                    {
                        return 0;
                    }

                    int[] charTable = MakeCharTable(needle);
                    int[] offsetTable = MakeOffsetTable(needle);
                    for (int i = needle.Length - 1; i < haystack.Length;)
                    {
                        int j;
                        for (j = needle.Length - 1; needle[j] == haystack[i]; --i, --j)
                        {
                            if (j == 0)
                            {
                                return i;
                            }
                        }

                        i += Math.Max(offsetTable[needle.Length - 1 - j], charTable[haystack[i]]);
                    }

                    return -1;
                }

                private static int[] MakeCharTable(byte[] needle)
                {
                    const int ALPHABET_SIZE = 256;
                    int[] table = new int[ALPHABET_SIZE];
                    for (int i = 0; i < table.Length; ++i)
                    {
                        table[i] = needle.Length;
                    }

                    for (int i = 0; i < needle.Length - 1; ++i)
                    {
                        table[needle[i]] = needle.Length - 1 - i;
                    }

                    return table;
                }

                private static int[] MakeOffsetTable(byte[] needle)
                {
                    int[] table = new int[needle.Length];
                    int lastPrefixPosition = needle.Length;
                    for (int i = needle.Length - 1; i >= 0; --i)
                    {
                        if (IsPrefix(needle, i + 1))
                        {
                            lastPrefixPosition = i + 1;
                        }

                        table[needle.Length - 1 - i] = lastPrefixPosition - i + needle.Length - 1;
                    }

                    for (int i = 0; i < needle.Length - 1; ++i)
                    {
                        int slen = SuffixLength(needle, i);
                        table[slen] = needle.Length - 1 - i + slen;
                    }

                    return table;
                }

                private static bool IsPrefix(byte[] needle, int p)
                {
                    for (int i = p, j = 0; i < needle.Length; ++i, ++j)
                    {
                        if (needle[i] != needle[j])
                        {
                            return false;
                        }
                    }

                    return true;
                }

                private static int SuffixLength(byte[] needle, int p)
                {
                    int len = 0;
                    for (int i = p, j = needle.Length - 1; i >= 0 && needle[i] == needle[j]; --i, --j)
                    {
                        len += 1;
                    }

                    return len;
                }
            }
        }

        public struct Range
        {
            public Range(int start, int end)
            {
                this.start = start;
                this.end = end;
            }
            public readonly int start, end;
        }
    }
}